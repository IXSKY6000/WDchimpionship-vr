# Documentation map

Start with:

- [Architecture](architecture.md) — host/runtime/guest ownership and seams.
- [Testing](testing.md) — evidence levels and test selection.
- [Publishing](publishing.md) — source hygiene and public-release checks.
- [Debugging](debugging.md) — reproduce, minimise, instrument, verify.
- [Configuration](configuration.md) — host settings and environment knobs.
- [Cheats](cheats.md) — session unlocks, original effects and ROM research.
- [Graphics capabilities](graphics-capabilities.md) — peer comparison and WDC limits.
- [Rendering and frame rate](rendering.md) — how a frame is produced, what
  caps it at 30 fps, and the routes to smoother motion.
- [Peer projects](peer-projects.md) — conventions distilled from AeroGauge and
  Automobili Lamborghini.
- [ROM reference](reference/rom.md) — measured identity, layout, and symbols.
- [Runtime reference](reference/runtime.md) — scheduler, threads, VI, and RSP.
- [Renderer reference](reference/renderer.md) — RT64 ownership and port hooks.
- [Distance and detail](reference/visibility.md) — car/track LOD, section pop-in and enhancement hooks.
- [Audio reference](reference/audio.md) — RSP audio and host output.
- [Input reference](reference/input.md) — peer controls patterns and shared frontend APIs.
- [Glossary](glossary.md) — project terminology.

Player-facing pages should stay short and avoid internal terms. Developer pages
should record stable facts and commands, not session chronology or guesses.
- [First playable](first-playable.md) - tested route, controls, limitations, next work.
