package org.ixsky.wdcquest;

import org.libsdl.app.SDLActivity;
import java.io.File;

public final class GameActivity extends SDLActivity {
    @Override protected String[] getLibraries() { return new String[] {"SDL2", "main"}; }
    @Override protected String[] getArguments() {
        return new String[] { new File(getFilesDir(), RomImport.FILENAME).getAbsolutePath() };
    }
}
