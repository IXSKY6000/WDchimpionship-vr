package org.ixsky.wdcquest;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.*;
import java.io.*;
import java.util.concurrent.*;

public final class LauncherActivity extends Activity {
    private static final int PICK_ROM = 1;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private TextView status;
    private Button play, select;
    private File rom;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        rom = new File(getFilesDir(), RomImport.FILENAME);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (24 * getResources().getDisplayMetrics().density);
        layout.setPadding(pad, pad, pad, pad);
        TextView title = new TextView(this);
        title.setText("World Driver Championship\nTest Android expérimental");
        title.setTextSize(24);
        layout.addView(title);
        TextView help = new TextView(this);
        help.setText("Version sur écran 2D : la VR n’est pas encore intégrée.\nManette Bluetooth nécessaire : Start pour les menus, A pour accélérer, B pour freiner, stick gauche pour diriger.\nImportez votre ROM USA .z64. Elle reste dans le stockage privé de cette application.");
        layout.addView(help);
        select = new Button(this);
        select.setText("Choisir ma ROM");
        select.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("*/*");
            try { startActivityForResult(intent, PICK_ROM); }
            catch (android.content.ActivityNotFoundException e) {
                status.setText("Le sélecteur de fichiers est indisponible sur cet appareil.");
            }
        });
        layout.addView(select);
        play = new Button(this);
        play.setText("Lancer le test");
        play.setEnabled(false);
        play.setOnClickListener(v -> startActivity(new Intent(this, GameActivity.class)));
        layout.addView(play);
        status = new TextView(this);
        status.setText("Vérification de la ROM…");
        layout.addView(status);
        setContentView(layout);
        select.setEnabled(false);
        worker.execute(() -> showResult(RomImport.isReady(rom), "Choisissez une ROM USA compatible."));
    }

    private void showResult(boolean ready, String message) {
        runOnUiThread(() -> {
            if (isFinishing() || isDestroyed()) return;
            play.setEnabled(ready);
            select.setEnabled(true);
            status.setText(ready ? "ROM USA vérifiée. Le test peut être lancé." : message);
        });
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request != PICK_ROM || result != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        play.setEnabled(false);
        select.setEnabled(false);
        status.setText("Importation et vérification…");
        worker.execute(() -> {
            String message = "Échec de l’importation.";
            try (InputStream input = getContentResolver().openInputStream(uri)) {
                if (input == null) throw new IOException("Fichier inaccessible.");
                RomImport.copyVerified(input, rom);
            } catch (IOException | SecurityException e) { message = e.getMessage(); }
            final String details = message;
            final boolean ready = RomImport.isReady(rom);
            runOnUiThread(() -> {
                if (!isFinishing() && !isDestroyed() && ready && !details.equals("Échec de l’importation."))
                    Toast.makeText(this, details, Toast.LENGTH_LONG).show();
            });
            showResult(ready, message);
        });
    }

    @Override protected void onDestroy() {
        worker.shutdown();
        super.onDestroy();
    }
}
