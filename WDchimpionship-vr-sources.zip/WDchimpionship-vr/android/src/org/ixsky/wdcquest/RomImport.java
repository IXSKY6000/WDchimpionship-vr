package org.ixsky.wdcquest;

import java.io.*;
import java.nio.file.*;
import java.security.*;

/** Validates a private import before atomically publishing it to the player. */
public final class RomImport {
    public static final long SIZE = 16777216;
    public static final String SHA256 = "e8e3734c5d2453c3a4bc940862545e2b84bdd65299e432548276fd71bccdfd97";
    public static final String FILENAME = "worlddriverchampionship.us.z64";

    private static MessageDigest sha256() {
        try { return MessageDigest.getInstance("SHA-256"); }
        catch (NoSuchAlgorithmException e) { throw new AssertionError(e); }
    }

    private static String hex(byte[] digest) {
        StringBuilder out = new StringBuilder();
        for (byte value : digest) out.append(String.format(java.util.Locale.ROOT, "%02x", value & 255));
        return out.toString();
    }

    public static void copyVerified(InputStream input, File destination) throws IOException {
        copyVerified(input, destination, SIZE, SHA256);
    }

    static void copyVerified(InputStream input, File destination, long size, String expected) throws IOException {
        File parent = destination.getParentFile();
        if (!parent.isDirectory() && !parent.mkdirs()) throw new IOException("Stockage privé indisponible.");
        File pending = File.createTempFile("rom-import-", ".part", parent);
        try {
            MessageDigest digest = sha256();
            long count = 0;
            try (FileOutputStream output = new FileOutputStream(pending)) {
                byte[] buffer = new byte[65536];
                int read;
                while ((read = input.read(buffer)) != -1) {
                    if (read == 0) continue;
                    count += read;
                    if (count > size) throw new IOException("La ROM dépasse la taille attendue.");
                    digest.update(buffer, 0, read);
                    output.write(buffer, 0, read);
                }
                if (count != size || !hex(digest.digest()).equals(expected)) {
                    throw new IOException("ROM incompatible. Sélectionnez la version USA originale au format .z64.");
                }
                output.getFD().sync();
            }
            Files.move(pending.toPath(), destination.toPath(), StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
        } finally {
            Files.deleteIfExists(pending.toPath());
        }
    }

    public static boolean isReady(File file) {
        if (!file.isFile() || file.length() != SIZE) return false;
        try (InputStream input = new FileInputStream(file)) {
            MessageDigest digest = sha256();
            byte[] buffer = new byte[65536];
            int read;
            while ((read = input.read(buffer)) != -1) digest.update(buffer, 0, read);
            return hex(digest.digest()).equals(SHA256);
        } catch (IOException e) { return false; }
    }
}
