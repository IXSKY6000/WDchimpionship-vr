# World Driver Championship — projet Quest 3

Objectif : port autonome Quest 3 avec vue depuis la voiture, stéréoscopie et
suivi de tête. **La VR n'est pas encore implémentée.**

Une première version **Android ARM64 sur écran 2D** compile et s'assemble en
APK de développement. Elle contient le vrai code CPU/RSP recompilé et le moteur
Vulkan RT64, un import de ROM vérifié, l'audio SDL et les entrées manette. Son
lancement et son rendu sur Quest restent à tester. Aucun fichier ROM n'est inclus.

Base : [alondero/worlddriverchampionship-recomp](https://github.com/alondero/worlddriverchampionship-recomp),
commit `344391a06cd0364f51f3318f65584181f8397b3a`, sous GPL-3.0. Les correctifs
Android du projet sont enregistrés dans `patches/` ; les dépendances restent
reproductibles depuis leurs versions épinglées.

## Essayer l'APK

Voir [les instructions Android](docs/ANDROID_TEST.md).
L'APK se trouve dans `dist/wdc-android-experimental.apk` après compilation.
Il nécessite une manette Bluetooth et votre ROM USA originale.

## Compiler dans cet environnement Linux

Python 3.11+, Java avec le module `jdk.compiler`, Git, GCC/G++ et accès aux
serveurs officiels GitHub, Google et PyPI sont nécessaires.

Depuis la racine de ce projet :

```sh
# Seulement si la base n'est pas déjà présente (archive source).
python3 tools/restore_upstream.py
python3 tools/bootstrap_toolchains.py --prefix /workspace/toolchains
export PATH="/workspace/toolchains/python/bin:$PATH"
python3 tools/build_android_player.py --init --rom "/chemin/World Driver Championship (USA).z64" --jobs 8
```

Pour reconstruire sur cette machine avec la traduction déjà présente :

```sh
python3 tools/build_android_player.py --reuse-translation --rom "/chemin/World Driver Championship (USA).z64" --jobs 8
```

La signature est une signature locale de développement. La clé reste dans le
répertoire des outils, hors des sources. Le script refuse de créer un APK avec
la bibliothèque de diagnostic CPU seule.

## Vérifications effectuées

- Identité exacte de la ROM USA vérifiée ; la ROM PAL précédente est incompatible.
- Traduction CPU/RSP et compilation native hôte réussies.
- Diagnostic hôte de 15 secondes : 11 threads invités, 900 interruptions VI et
  443 tâches graphiques ; aucun affichage dans ce diagnostic.
- Compilation ARM64 du noyau, puis du lecteur SDL/Vulkan complet, réussie.
- 9 tests CTest réussis, dont caméra, conduite, démarrage, sauvegardes et RSP.
- 5 tests Python du vérificateur réussis ; importateur Java testé avec des données
  invalides et avec la véritable ROM USA.
- Signature et alignement de l'APK contrôlés ; bibliothèques ARM64 et absence de
  fichier ROM contrôlées dans l'archive.

Ces vérifications ne valident ni l'affichage, ni l'audio, ni les commandes sur un
Quest physique. Voir [l'état technique](docs/feasibility.md) pour les limites et
les étapes VR restantes. Aucun test de performance sur casque n'est revendiqué.
