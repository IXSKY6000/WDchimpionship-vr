package org.ixsky.wdcquest;

import java.io.*;
import java.nio.file.*;
import java.security.*;
import java.util.*;

/** Host tests for the exact importer used by the Android launcher. */
public final class RomImportTest {
    private static void check(boolean value, String message) {
        if (!value) throw new AssertionError(message);
    }

    public static void main(String[] args) throws Exception {
        Path directory = Files.createTempDirectory("wdc-rom-test-");
        try {
            File target = directory.resolve("game.z64").toFile();
            byte[] good = "fixture-payload".getBytes("UTF-8");
            StringBuilder digest = new StringBuilder();
            for (byte b : MessageDigest.getInstance("SHA-256").digest(good)) digest.append(String.format("%02x", b & 255));
            String sha = digest.toString();
            RomImport.copyVerified(new ByteArrayInputStream(good), target, good.length, sha);
            check(Arrays.equals(good, Files.readAllBytes(target.toPath())), "exact import differs");
            // A bad import must preserve the already verified file and remove
            // its temporary file, including when a provider fails mid-stream.
            byte[] corrupted = good.clone(); corrupted[3] ^= 1;
            InputStream[] bad = {
                new ByteArrayInputStream(Arrays.copyOf(good, good.length - 1)),
                new ByteArrayInputStream(Arrays.copyOf(good, good.length + 1)),
                new ByteArrayInputStream(corrupted),
                new InputStream() { public int read() throws IOException { throw new IOException("provider failed"); } }
            };
            for (InputStream stream : bad) {
                boolean rejected = false;
                try { RomImport.copyVerified(stream, target, good.length, sha); }
                catch (IOException expected) { rejected = true; }
                check(rejected, "bad stream accepted");
                check(Arrays.equals(good, Files.readAllBytes(target.toPath())), "existing ROM damaged");
                try (java.util.stream.Stream<Path> files = Files.list(directory)) {
                    check(files.count() == 1, "temporary import leaked");
                }
            }
            check(!RomImport.isReady(target), "synthetic ROM passed production identity");
            check(!RomImport.isReady(directory.resolve("missing.z64").toFile()), "missing ROM accepted");
            if (args.length == 1) {
                File real = new File(args[0]);
                check(RomImport.isReady(real), "supplied USA ROM rejected");
                try (InputStream input = new FileInputStream(real)) { RomImport.copyVerified(input, target); }
                check(RomImport.isReady(target), "imported USA ROM rejected");
                System.out.println("Real USA ROM: import and identity verified");
            }
            System.out.println("Importer: exact copy, truncation, oversize, corruption, provider error, preservation and cleanup passed");
        } finally {
            try (java.util.stream.Stream<Path> files = Files.list(directory)) {
                for (Path file : (Iterable<Path>) files::iterator) Files.delete(file);
            }
            Files.delete(directory);
        }
    }
}
