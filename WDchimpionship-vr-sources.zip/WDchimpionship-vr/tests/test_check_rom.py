import hashlib
from pathlib import Path
import tempfile
import unittest

from tools.check_rom import inspect_rom


class RomInspectionTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.path = Path(self.temp.name) / "fixture.z64"
        data = bytearray(128)
        data[:4] = bytes.fromhex("80371240")
        data[8:12] = bytes.fromhex("80000400")
        data[32:52] = b"WORLD DRIVER CHAMP  "
        data[59:63] = b"NWOP"
        self.data = bytes(data)
        self.path.write_bytes(self.data)
        self.expected = {"rom_size": 128, "sha256": hashlib.sha256(self.data).hexdigest()}

    def test_exact_identity_is_required_and_never_claims_vr(self):
        report = inspect_rom(self.path, self.expected)
        self.assertTrue(report["upstream_cpu_translation_compatible"])
        self.assertFalse(report["quest_vr_ready"])
        self.assertEqual(report["cartridge_id"], "NWOP")
        self.assertEqual(report["entrypoint"], "0x80000400")
        self.assertEqual(self.path.read_bytes(), self.data)

    def test_same_header_different_payload_rejected(self):
        self.path.write_bytes(self.data[:-1] + b"\x01")
        report = inspect_rom(self.path, self.expected)
        self.assertEqual(report["errors"], ["sha256_mismatch"])

    def test_truncated_dump_rejected(self):
        self.path.write_bytes(self.data[:12])
        report = inspect_rom(self.path, self.expected)
        self.assertIn("truncated_header", report["errors"])
        self.assertIn("size_mismatch", report["errors"])
        self.assertFalse(report["upstream_cpu_translation_compatible"])

    def test_byte_swapped_dump_rejected(self):
        data = bytearray(self.data)
        data[:4] = bytes.fromhex("37804012")
        self.path.write_bytes(data)
        self.assertIn("not_big_endian_z64", inspect_rom(self.path, self.expected)["errors"])

    def test_missing_file_is_an_io_error(self):
        with self.assertRaises(FileNotFoundError):
            inspect_rom(self.path.with_name("missing.z64"), self.expected)


if __name__ == "__main__":
    unittest.main()
