# État technique — 3 novembre 2026

## Résultats locaux

Base : [World Driver Championship: Recompiled](https://github.com/alondero/worlddriverchampionship-recomp),
commit `344391a06cd0364f51f3318f65584181f8397b3a`. L'amont annonce une première
version Windows jouable. Ce projet a maintenant compilé et exécuté son noyau
CPU/RSP sous Linux, puis compilé un lecteur Android ARM64 avec SDL et Vulkan.

| Étape | Résultat mesuré |
|---|---|
| ROM USA | SHA-256 conforme ; cartouche NWOE, 16 Mio |
| ROM PAL précédente | Rejet confirmé par le générateur amont ; contrôle d'intégrité conservé |
| Traduction | CPU N64 et microcode BOSS générés avec les outils épinglés et correctifs amont |
| Diagnostic hôte | 15 secondes, sortie 2 attendue, boot=1, 11 threads, 900 VI, 443 tâches graphiques |
| Tests natifs | 9 CTest réussis : conduite, visibilité, démarrage, cheats, Controller Pak, menus, caméra, DMA RSP, replay BOSS |
| Import ROM | Vrai dump USA vérifié ; rejet troncature/surplus/corruption/erreur de lecture ; préservation du fichier existant et nettoyage temporaire |
| Android | NDK r28c, API minimale 29, ARM64 ; noyau puis lecteur SDL/Vulkan complet compilés |
| APK | Assemblage et reconstruction réussis ; signature v3 et alignement contrôlés, SDL_main exporté, bibliothèques ARM64, pas de fichier ROM |
| Quest physique | Non testé : aucun casque ni périphérique USB disponible dans cette machine |
| VR | OpenXR, stéréoscopie et suivi de tête non implémentés |

Le diagnostic termine volontairement avec le code 2 : il prouve la progression
CPU/RSP et ne représente pas une partie jouée. Un essai pendant la compilation
parallèle a échoué au seuil de cadence (770 VI) ; l'essai relancé sans compilation
concurrente a atteint 900 VI. Ce n'est pas un benchmark du Quest.

Les relevés sont dans `docs/evidence/`. L'APK actuel est une première étape
Android 2D et ne doit pas être présenté comme le port VR demandé terminé.

## Adaptations Android réalisées

- Point d'entrée `SDL_main`, fenêtre Vulkan, données et sauvegardes dans le
  stockage privé Android ; import via le sélecteur de documents.
- Manette analogique et boutons N64 sans le frontal de bureau ; connexion et
  déconnexion SDL.
- Inclusion SSE2NEON nécessaire au microcode BOSS sur ARM64.
- Outils de shader exécutés sur l'hôte, bibliothèques compilées pour ARM64 ;
  shaders SPIR-V compilés pendant le build.
- Surface Vulkan Android SDL dans Plume et RT64 ; chemins de stockage dédiés.
- Formation de dictionnaires Zstd désactivée : inutilisée par le lecteur et
  dépendante de `qsort_r`, absent à l'API cible. Compression et décompression
  restent compilées.
- Les dialogues de l'inspecteur de bureau retournent une annulation sur Android.
  L'import du jeu utilise l'interface Android.

Ces changements sont exportés dans `wdc-android.patch`, `rt64-android.patch` et
`plume-android.patch`. Les correctifs RDP/runtime amont sont appliqués séparément.
Les scripts refusent d'écraser des modifications locales sur leurs chemins.

## Travaux VR restants

1. Valider le lecteur sur Quest : exigences Vulkan du pilote, rendu, audio,
   entrées, sauvegardes et reprise. Compiler ne valide pas le matériel.
2. Confirmer en jeu la vue de conduite et la géométrie de l'intérieur. Leur
   présence n'a pas été vérifiée par une exécution locale.
3. Séparer simulation et émission de scène avant le ZSort, puis générer une vue
   par œil sans avancer la simulation deux fois.
4. Intégrer OpenXR : choix du GPU Vulkan, cycle de session, prédiction des poses,
   espaces assis, swapchains, synchronisation, contrôleurs Touch, recentrage et HUD.
5. Mesurer cadence, latence, confort, mémoire et température sur Quest 3, puis
   vérifier plusieurs circuits et sauvegardes.

L'amont documente dans `docs/rendering.md` que les triangles de course viennent
du ZSort CPU après transformation par la caméra. Rejouer BOSS avec une autre
matrice ne fournit pas un second point de vue. Un écran virtuel ou un changement
de FOV ne résout pas cette séparation.
