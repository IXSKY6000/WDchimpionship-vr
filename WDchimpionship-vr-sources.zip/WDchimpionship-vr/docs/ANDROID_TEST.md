# Tester la première version Android

Cette version est un **test sur écran 2D**, avant intégration VR. Elle n'a pas
encore été lancée sur un Quest physique. Le suivi de tête, les contrôleurs Touch
via OpenXR et la stéréoscopie ne sont pas présents.

## Installation sur Quest 3

1. Activer le mode développeur du Quest et autoriser la connexion USB à
   l'ordinateur utilisé pour l'installation.
2. Installer `wdc-android-experimental.apk` via SideQuest, ou utiliser :

   ```sh
   adb install -r wdc-android-experimental.apk
   ```

3. Copier votre fichier `World Driver Championship (USA).z64` dans le dossier
   Téléchargements du casque. Connecter une manette Bluetooth au Quest.
4. Dans les applications de sources inconnues, ouvrir **WDC — Android
   expérimental**. Choisir la ROM, attendre sa vérification et lancer le test.

La ROM doit avoir le SHA-256
`e8e3734c5d2453c3a4bc940862545e2b84bdd65299e432548276fd71bccdfd97`.
L'importateur copie le fichier dans le stockage privé de l'application après
vérification ; il ne télécharge pas de ROM et ne demande pas d'accès global au
stockage. Les sauvegardes restent dans ce stockage privé.

## Commandes prévues pour une manette standard

| Manette | Entrée N64 |
|---|---|
| Start | Start / pause |
| A | A / accélération |
| B | B / frein |
| Stick gauche | Stick analogique |
| Croix directionnelle | Croix directionnelle |
| Y, X | C-haut, C-bas |
| Épaule droite | R |
| Épaule gauche | Z |

Les correspondances sont compilées dans le lecteur. Leur fonctionnement sur
une manette particulière et la sélection de la vue de conduite restent à
vérifier dans le jeu. Les contrôleurs Touch ne sont pas assimilés à une manette
Bluetooth.

## Parcours de validation

Vérifier successivement : import de ROM, lancement, intro, menus, course de
practice à Hawaii, direction/accélération/frein, pause, son et sauvegarde après
relancement. La version amont documente : Start au titre, A pour Quick Race,
Bas puis A pour Practice Laps, A pour Hawaii, A pour transmission automatique.
Ce parcours n'a pas encore été exécuté sur l'APK.

En cas d'écran noir ou de fermeture, recueillir le journal juste après le
problème :

```sh
adb logcat -d -t 1500 > wdc-quest-log.txt
```

Indiquer aussi le dernier écran atteint, le modèle de manette et la version du
système du Quest. Ne pas conclure qu'une compilation ou une installation valide
le rendu : les exigences Vulkan de RT64 doivent être confrontées au GPU et au
pilote réels du casque.
