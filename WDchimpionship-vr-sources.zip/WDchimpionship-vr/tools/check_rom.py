#!/usr/bin/env python3
"""Inspect a dump without modifying it; check the pinned recompiler's identity.

Exit 0: compatible with the upstream CPU translator (NOT Android/VR ready).
Exit 2: incompatible or invalid dump. Exit 1: filesystem/configuration error.
Python 3.11+, standard library only. No ROM contents are emitted.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import struct
import sys
import tomllib

ROOT = Path(__file__).resolve().parents[1]
ANALYSIS = ROOT / "vendor/wdc-recomp/rom-analysis.toml"


def inspect_rom(path: Path, expected: dict) -> dict:
    digest = hashlib.sha256()
    size = 0
    with path.open("rb") as stream:
        header = stream.read(64)
        digest.update(header)
        size += len(header)
        while chunk := stream.read(1024 * 1024):
            digest.update(chunk)
            size += len(chunk)
    sha256 = digest.hexdigest()
    errors = []
    if len(header) < 64:
        errors.append("truncated_header")
    if header[:4] != bytes.fromhex("80371240"):
        errors.append("not_big_endian_z64")
    if size != expected["rom_size"]:
        errors.append("size_mismatch")
    if sha256 != expected["sha256"]:
        errors.append("sha256_mismatch")
    return {
        "size_bytes": size,
        "sha256": sha256,
        "magic": header[:4].hex(),
        "title": header[32:52].decode("ascii", errors="replace").rstrip(" \x00"),
        "cartridge_id": header[59:63].decode("ascii", errors="replace"),
        "revision": header[63] if len(header) == 64 else None,
        "entrypoint": f"0x{struct.unpack_from('>I', header, 8)[0]:08X}" if len(header) >= 12 else None,
        "upstream_expected_sha256": expected["sha256"],
        "upstream_cpu_translation_compatible": not errors,
        "errors": errors,
        "quest_vr_ready": False,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("rom", type=Path)
    args = parser.parse_args()
    try:
        expected = tomllib.loads(ANALYSIS.read_text(encoding="utf-8"))["rom"]
        report = inspect_rom(args.rom, expected)
    except (OSError, ValueError, KeyError) as exc:
        print(f"Cannot inspect ROM: {exc}", file=sys.stderr)
        return 1
    print(json.dumps(report, indent=2, ensure_ascii=False))
    return 0 if report["upstream_cpu_translation_compatible"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
