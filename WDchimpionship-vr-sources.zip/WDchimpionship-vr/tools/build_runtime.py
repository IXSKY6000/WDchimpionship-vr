#!/usr/bin/env python3
"""Translate the verified USA ROM and build the bounded native runtime.

This is the CPU/RSP prerequisite for the Quest port, not an APK builder.
Requires CMake >=3.20, Ninja, a C++20 compiler and Python >=3.11 on PATH.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tomllib

from check_rom import inspect_rom

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "vendor/wdc-recomp"
RUNTIME_PATCHES = [
    "0006-runtime-lle-interrupt-ownership.patch",
    "0008-runtime-controller-pak-kind.patch",
    "0009-runtime-host-config-storage.patch",
    "0013-runtime-rsp-unsigned-packed-loads.patch",
    "0018-runtime-rsp-dma-rounding.patch",
]


def run(*args: object, cwd: Path = SOURCE) -> None:
    command = [str(arg) for arg in args]
    print("+", subprocess.list2cmdline(command), flush=True)
    subprocess.run(command, cwd=cwd, check=True)


def port_patch(dependency: Path, patch: Path) -> None:
    if not patch.is_file():
        raise FileNotFoundError(patch)
    if subprocess.run(["git", "apply", "--reverse", "--check", str(patch)], cwd=dependency, capture_output=True).returncode == 0:
        return
    run("git", "apply", "--check", patch, cwd=dependency)
    run("git", "apply", patch, cwd=dependency)


def patches(submodule: str, names: list[str]) -> None:
    # The upstream helper restores paths unconditionally. Protect local edits
    # and only call it on clean paths; on repeat, verify the recorded outputs.
    spec = importlib.util.spec_from_file_location("patch_series", SOURCE / "scripts/patch_series.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    inputs = [SOURCE / "patches" / name for name in names]
    owned, created = module.parse_series(inputs)
    dependency = SOURCE / submodule
    fingerprint = hashlib.sha256(b"".join(p.read_bytes() for p in inputs)).hexdigest()
    def files():
        return {name: hashlib.sha256((dependency / name).read_bytes()).hexdigest()
                if (dependency / name).is_file() else None for name in owned}
    stamp = ROOT / "build/patch-state" / (submodule.replace("/", "_") + ".json")
    if stamp.exists():
        previous = json.loads(stamp.read_text())
        if previous == {"patches": fingerprint, "files": files()}:
            return
        raise RuntimeError(f"Dependency patches or local files changed: {dependency}; refusing to overwrite")
    dirty = subprocess.check_output(["git", "diff", "HEAD", "--", *owned], cwd=dependency)
    if dirty or any((dependency / path).exists() for path in created):
        raise RuntimeError(f"Local edits in patch-owned paths: {dependency}; refusing to overwrite")
    command = [sys.executable, "-B", "scripts/patch_series.py", "--submodule", submodule]
    for name in names:
        command += ["--patch", str(SOURCE / "patches" / name)]
    run(*command)
    stamp.parent.mkdir(parents=True, exist_ok=True)
    stamp.write_text(json.dumps({"patches": fingerprint, "files": files()}, indent=2) + "\n")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--rom", required=True, type=Path)
    parser.add_argument("--jobs", type=int, default=min(8, os.cpu_count() or 2))
    parser.add_argument("--init", action="store_true", help="Fetch pinned CPU/RSP dependencies first")
    parser.add_argument("--android-ndk", type=Path, help="Cross-compile ARM64 CPU/RSP library instead of host diagnostic")
    args = parser.parse_args()
    if args.jobs < 1:
        parser.error("--jobs must be positive")
    analysis = tomllib.loads((SOURCE / "rom-analysis.toml").read_text())["rom"]
    report = inspect_rom(args.rom, analysis)
    if not report["upstream_cpu_translation_compatible"]:
        parser.error("ROM does not match the pinned USA analysis: " + ", ".join(report["errors"]))
    dest = SOURCE / analysis["filename"]
    if dest.exists():
        if not inspect_rom(dest, analysis)["upstream_cpu_translation_compatible"]:
            parser.error("Refusing to overwrite a different ROM already in the source tree")
    else:
        shutil.copyfile(args.rom, dest)
    if args.init:
        run("git", "submodule", "update", "--init", "--recursive", "lib/N64ModernRuntime")
        run("git", "submodule", "update", "--init", "--depth", "1", "lib/rt64", "lib/RecompFrontend")
    port_patch(SOURCE, ROOT / "patches/wdc-android.patch")
    patches("lib/N64ModernRuntime", RUNTIME_PATCHES)
    patches("lib/N64ModernRuntime/N64Recomp", ["0007-rsprecomp-boss-support.patch"])
    host = ROOT / "build/host-tools"
    run("cmake", "-S", SOURCE / "android/host-tools", "-B", host, "-G", "Ninja", "-DCMAKE_BUILD_TYPE=Release")
    run("cmake", "--build", host, "--target", "N64RecompCLI", "RSPRecomp", "--parallel", args.jobs)
    run(sys.executable, "-B", "scripts/gen_syms_toml.py")
    recompiler = host / "N64ModernRuntime/librecomp/N64Recomp"
    run(recompiler / "N64Recomp", "worlddriverchampionship.us.toml")
    run(recompiler / "RSPRecomp", "aspMain.us.toml")
    build = ROOT / ("build/android-runtime" if args.android_ndk else "build/host-runtime")
    options = ["-DWDC_HEADLESS=ON", "-DWDC_ENABLE_FRONTEND=OFF", "-DCMAKE_BUILD_TYPE=Release"]
    if args.android_ndk:
        toolchain = args.android_ndk.resolve() / "build/cmake/android.toolchain.cmake"
        if not toolchain.is_file():
            parser.error(f"Missing Android NDK toolchain: {toolchain}")
        options += [f"-DCMAKE_TOOLCHAIN_FILE={toolchain}", "-DANDROID_ABI=arm64-v8a", "-DANDROID_PLATFORM=android-29", "-DANDROID_STL=c++_static", "-DBUILD_TESTING=OFF"]
    run("cmake", "-S", SOURCE, "-B", build, "-G", "Ninja", *options)
    run("cmake", "--build", build, "--target", "worlddriverchampionship_modern", "--parallel", args.jobs)
    print("CPU/RSP runtime built. No Android graphics or VR readiness is implied.")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except subprocess.CalledProcessError as exc:
        raise SystemExit(exc.returncode)
