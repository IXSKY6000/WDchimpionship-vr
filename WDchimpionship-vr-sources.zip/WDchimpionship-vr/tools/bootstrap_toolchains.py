#!/usr/bin/env python3
"""Install pinned build tools locally; verify Android archives against Google metadata."""
from pathlib import Path
import argparse
import hashlib
import os
import stat
import subprocess
import sys
import urllib.request
import venv
import xml.etree.ElementTree as ET
import zipfile

PACKAGES = {
    "platforms;android-35": "platforms/android-35",
    "ndk;28.2.13676358": "ndk/28.2.13676358",
    "build-tools;35.0.0": "build-tools/35.0.0",
}
SDL_COMMIT = "8236e01a9f758d15927624925c6043f84d8a261f"


def sha1(path):
    result = hashlib.sha1()
    with path.open("rb") as stream:
        while chunk := stream.read(1024 * 1024):
            result.update(chunk)
    return result.hexdigest()


def unpack(archive, parent):
    # Preserve NDK symlinks; zipfile.extractall alone turns them into text files.
    parent = parent.resolve()
    with zipfile.ZipFile(archive) as zipped:
        entries = zipped.infolist()
        for info in entries:
            path = (parent / info.filename).resolve()
            if not path.is_relative_to(parent):
                raise ValueError("Archive path escapes extraction root")
            if stat.S_ISLNK(info.external_attr >> 16):
                target = zipped.read(info).decode()
                if not (path.parent / target).resolve().is_relative_to(parent):
                    raise ValueError("Archive symlink escapes extraction root")
        zipped.extractall(parent)
        for info in entries:
            path = parent / info.filename
            mode = info.external_attr >> 16
            if stat.S_ISLNK(mode):
                path.unlink()
                path.symlink_to(zipped.read(info).decode())
            elif mode & 0o111:
                path.chmod(mode & 0o777)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--prefix", type=Path, default=Path("/workspace/toolchains"))
    args = parser.parse_args()
    prefix = args.prefix.resolve()
    prefix.mkdir(parents=True, exist_ok=True)
    python = prefix / "python/bin/python"
    if not python.exists():
        venv.create(prefix / "python", with_pip=True)
    subprocess.run([python, "-m", "pip", "install", "cmake==3.31.6", "ninja==1.11.1.4"], check=True)
    cache = prefix / "downloads"
    cache.mkdir(exist_ok=True)
    sdk = prefix / "android"
    sdk.mkdir(exist_ok=True)
    with urllib.request.urlopen("https://dl.google.com/android/repository/repository2-3.xml", timeout=60) as response:
        metadata = ET.fromstring(response.read())
    for package, relative in PACKAGES.items():
        dest = sdk / relative
        if dest.is_dir():
            print("Retaining installed package:", package, flush=True)
            continue
        node = next(n for n in metadata.findall("remotePackage") if n.attrib.get("path") == package)
        archive = next(n.find("complete") for n in node.findall("./archives/archive") if n.findtext("host-os") in (None, "linux"))
        url = archive.findtext("url")
        cached = cache / Path(url).name
        expected = archive.findtext("checksum")
        if not cached.exists() or sha1(cached) != expected:
            print("Downloading", package, flush=True)
            urllib.request.urlretrieve("https://dl.google.com/android/repository/" + url, cached)
        if sha1(cached) != expected:
            raise ValueError(f"Archive checksum mismatch: {cached}")
        temporary = sdk / ("unpack-" + package.split(";")[0])
        if temporary.exists():
            raise FileExistsError(f"Inspect incomplete previous extraction before continuing: {temporary}")
        temporary.mkdir()
        unpack(cached, temporary)
        children = list(temporary.iterdir())
        if len(children) != 1:
            raise ValueError("Unexpected archive layout")
        dest.parent.mkdir(parents=True, exist_ok=True)
        children[0].rename(dest)
        temporary.rmdir()
    sdl = prefix / "SDL"
    if not sdl.exists():
        subprocess.run(["git", "clone", "--depth", "1", "--branch", "release-2.30.12", "https://github.com/libsdl-org/SDL.git", sdl], check=True)
    commit = subprocess.check_output(["git", "-C", sdl, "rev-parse", "HEAD"], text=True).strip()
    if commit != SDL_COMMIT:
        raise ValueError("SDL checkout differs from the reviewed pin; refusing to change it")
    subprocess.run([sdk / "ndk/28.2.13676358/toolchains/llvm/prebuilt/linux-x86_64/bin/clang", "--version"], check=True)
    subprocess.run(["java", "com.sun.tools.javac.Main", "-version"], check=True)
    print(f"Toolchains installed. Add {prefix / 'python/bin'} to PATH.")


if __name__ == "__main__":
    main()
