#!/usr/bin/env python3
"""Package the ARM64 SDL/Vulkan player as a development APK (not a VR APK).

Uses the SDK directly so no unpinned Gradle/Maven downloads are necessary.
Refuses to package a CPU-only library or include ROMs/generated game sources.
"""
from __future__ import annotations

import argparse
from pathlib import Path
import shutil
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[1]


def run(*args: object) -> None:
    subprocess.run([str(arg) for arg in args], check=True, cwd=ROOT)


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--sdk", required=True, type=Path)
    p.add_argument("--sdl", required=True, type=Path)
    p.add_argument("--native-build", type=Path, default=ROOT / "build/android-player")
    p.add_argument("--keystore", required=True, type=Path, help="Local development-only signing keystore")
    args = p.parse_args()
    sdk = args.sdk.resolve()
    native = args.native_build.resolve()
    ndk = sdk / "ndk/28.2.13676358/toolchains/llvm/prebuilt/linux-x86_64/bin"
    symbols = subprocess.check_output([str(ndk / "llvm-nm"), "-D", "--defined-only", str(native / "libmain.so")], text=True)
    if not any(line.split()[-1:] == ["SDL_main"] for line in symbols.splitlines()):
        p.error("libmain.so does not export SDL_main: refusing to package a CPU-only build")
    for library in [native / "libmain.so", native / "SDL/libSDL2.so"]:
        header = subprocess.check_output([str(ndk / "llvm-readelf"), "-h", str(library)], text=True)
        if "AArch64" not in header:
            p.error(f"Not an ARM64 library: {library}")
    build = ROOT / "build/apk"
    # This directory contains disposable packaging outputs only.
    if build.exists():
        shutil.rmtree(build)
    (build / "classes").mkdir(parents=True)
    (build / "dex").mkdir()
    android = sdk / "platforms/android-35/android.jar"
    tools = sdk / "build-tools/35.0.0"
    sources = sorted((ROOT / "android/src").rglob("*.java")) + sorted((args.sdl / "android-project/app/src/main/java").rglob("*.java"))
    run("java", "com.sun.tools.javac.Main", "-encoding", "UTF-8", "-source", "8", "-target", "8", "-classpath", android, "-d", build / "classes", *sources)
    run(tools / "d8", "--min-api", "29", "--lib", android, "--output", build / "dex", *sorted((build / "classes").rglob("*.class")))
    run(tools / "aapt2", "link", "-I", android, "--manifest", ROOT / "android/AndroidManifest.xml", "-o", build / "unsigned.apk")
    with zipfile.ZipFile(build / "unsigned.apk", "a", zipfile.ZIP_DEFLATED) as apk:
        for dex in sorted((build / "dex").glob("*.dex")):
            apk.write(dex, dex.name)
        for source, target in [(native / "libmain.so", "libmain.so"), (native / "SDL/libSDL2.so", "libSDL2.so")]:
            stripped = build / target
            shutil.copyfile(source, stripped)
            run(ndk / "llvm-strip", "--strip-debug", stripped)
            apk.write(stripped, "lib/arm64-v8a/" + target)
        for label, source_root in [("wdc-recomp", ROOT / "vendor/wdc-recomp"), ("SDL", args.sdl)]:
            for license_path in sorted(source_root.rglob("*")):
                relative = license_path.relative_to(source_root)
                if any(part in {".git", "build", "RecompiledFuncs", "__pycache__"} for part in relative.parts):
                    continue
                if license_path.is_file() and license_path.name.lower().startswith(("license", "licence", "copying", "notice", "copyright")):
                    apk.write(license_path, f"assets/licenses/{label}/{relative}")
        apk.writestr("assets/licenses/SOURCE.txt", "Unofficial experimental Android port.\nPort source: IXSKY6000/WDchimpionship-vr\nBase: https://github.com/alondero/worlddriverchampionship-recomp/tree/344391a06cd0364f51f3318f65584181f8397b3a (GPL-3.0)\nSDL: https://github.com/libsdl-org/SDL/tree/8236e01a9f758d15927624925c6043f84d8a261f\nDependency notices retain their original licenses. Original game data is not included.\n")
    with zipfile.ZipFile(build / "unsigned.apk") as apk:
        if any(Path(n).suffix.lower() in {".z64", ".n64", ".v64", ".rom", ".mpk"} for n in apk.namelist()):
            p.error("Forbidden game data found in APK")
    run(tools / "zipalign", "-f", "-P", "16", "4", build / "unsigned.apk", build / "aligned.apk")
    if not args.keystore.exists():
        args.keystore.parent.mkdir(parents=True, exist_ok=True)
        run("keytool", "-genkeypair", "-noprompt", "-keystore", args.keystore, "-storepass", "android", "-keypass", "android", "-alias", "androiddebugkey", "-dname", "CN=WDC Development", "-keyalg", "RSA", "-keysize", "2048", "-validity", "10000")
    output = ROOT / "dist/wdc-android-experimental.apk"
    output.parent.mkdir(exist_ok=True)
    run(tools / "apksigner", "sign", "--ks", args.keystore, "--ks-pass", "pass:android", "--key-pass", "pass:android", "--out", output, build / "aligned.apk")
    run(tools / "apksigner", "verify", "--verbose", output)
    run(tools / "zipalign", "-c", "-P", "16", "4", output)
    print(f"Development 2D APK: {output}; device launch and rendering remain unverified.")


if __name__ == "__main__":
    main()
