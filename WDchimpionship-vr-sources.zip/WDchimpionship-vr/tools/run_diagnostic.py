#!/usr/bin/env python3
"""Check the bounded upstream CPU/RSP diagnostic; never interpret its exit 2 as gameplay success."""
import argparse
import json
from pathlib import Path
import re
import subprocess

ROOT = Path(__file__).resolve().parents[1]


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--rom", required=True, type=Path)
    args = p.parse_args()
    log = ROOT / "build/host-diagnostic.log"
    with log.open("w") as output:
        try:
            result = subprocess.run([ROOT / "build/host-runtime/worlddriverchampionship_modern", args.rom.resolve()],
                                    cwd=ROOT, stdout=output, stderr=subprocess.STDOUT, timeout=25)
        except subprocess.TimeoutExpired:
            raise SystemExit("Diagnostic did not finish at its own 15-second limit; see build/host-diagnostic.log")
    text = log.read_text(errors="replace")
    match = re.search(r"diagnostic timeout: boot=(\d+) threads=(\d+) vis=(\d+) graphics=(\d+)", text)
    if result.returncode != 2 or not match:
        raise SystemExit(f"Unexpected diagnostic result {result.returncode}; see build/host-diagnostic.log")
    boot, threads, vis, graphics = map(int, match.groups())
    if boot != 1 or threads < 1 or vis < 800 or graphics < 1:
        raise SystemExit("CPU/RSP startup did not progress adequately; see build/host-diagnostic.log")
    print(json.dumps({"diagnostic_exit_code": result.returncode, "boot": bool(boot), "guest_threads": threads,
                      "vi_interrupts": vis, "graphics_tasks": graphics, "duration_seconds": 15,
                      "scope": "CPU/RSP startup only", "gameplay_validated": False, "quest_validated": False}, indent=2))


if __name__ == "__main__":
    main()
