#!/usr/bin/env python3
"""Restore the pinned base when building from the source archive (which omits Git metadata)."""
import argparse
from pathlib import Path
import subprocess

PIN = "344391a06cd0364f51f3318f65584181f8397b3a"
URL = "https://github.com/alondero/worlddriverchampionship-recomp.git"
ROOT = Path(__file__).resolve().parents[1]


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--destination", type=Path, default=ROOT / "vendor/wdc-recomp")
    dest = p.parse_args().destination.resolve()
    if (dest / ".git").exists():
        head = subprocess.run(["git", "-C", dest, "rev-parse", "--verify", "HEAD^{commit}"], capture_output=True, text=True)
        if head.returncode == 0:
            if head.stdout.strip() != PIN:
                p.error("Existing source checkout differs from the pinned base; refusing to reset it")
            print("Retaining pinned source checkout and local changes")
            return
        # A runtime restart can interrupt the initial fetch. Only resume a
        # positively identified empty, unborn checkout created for this URL.
        branch = subprocess.run(["git", "-C", dest, "symbolic-ref", "HEAD"], capture_output=True, text=True)
        ref = subprocess.run(["git", "-C", dest, "show-ref", "--verify", "--quiet", branch.stdout.strip()], capture_output=True)
        remote = subprocess.run(["git", "-C", dest, "remote", "get-url", "origin"], capture_output=True, text=True)
        tracked = subprocess.check_output(["git", "-C", dest, "ls-files"])
        if branch.returncode != 0 or ref.returncode != 1 or tracked or remote.stdout.strip() != URL or any(f.name != ".git" for f in dest.iterdir()):
            p.error("Existing checkout is not a verified empty initial fetch; refusing to change it")
        for command in [["git", "-C", str(dest), "fetch", "--depth", "1", "origin", PIN], ["git", "-C", str(dest), "checkout", "--detach", PIN]]:
            subprocess.run(command, check=True)
        return
    if dest.exists() and any(dest.iterdir()):
        p.error("Destination is nonempty without Git metadata; refusing to overwrite it")
    dest.mkdir(parents=True, exist_ok=True)
    for args in [["git", "init", str(dest)], ["git", "-C", str(dest), "remote", "add", "origin", URL],
                 ["git", "-C", str(dest), "fetch", "--depth", "1", "origin", PIN],
                 ["git", "-C", str(dest), "checkout", "--detach", PIN]]:
        subprocess.run(args, check=True)


if __name__ == "__main__":
    main()
