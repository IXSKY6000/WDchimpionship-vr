#!/usr/bin/env python3
"""Build the experimental flat-screen Android player, before OpenXR integration."""
import argparse
from pathlib import Path
import subprocess
import sys

from build_runtime import ROOT, SOURCE, run, patches, port_patch

GPU_DEPENDENCIES = ["ddspp", "dxc", "hlslpp", "im3d", "imgui", "implot", "plume", "re-spirv", "spirv-cross", "stb", "xxHash", "zstd"]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--rom", required=True, type=Path)
    parser.add_argument("--toolchains", type=Path, default=Path("/workspace/toolchains"))
    parser.add_argument("--jobs", type=int, default=8)
    parser.add_argument("--init", action="store_true", help="Fetch missing pinned dependencies")
    parser.add_argument("--reuse-translation", action="store_true", help="Reuse this instance's translated USA code; validate the input ROM first")
    args = parser.parse_args()
    if args.jobs < 1:
        parser.error("--jobs must be positive")
    toolchains = args.toolchains.resolve()
    runtime_args = [sys.executable, ROOT / "tools/build_runtime.py", "--rom", args.rom.resolve(), "--jobs", args.jobs]
    if args.init:
        run("git", "submodule", "update", "--init", "--depth", "1", "lib/rt64", "lib/RecompFrontend")
        runtime_args.append("--init")
    if args.reuse_translation:
        run(sys.executable, ROOT / "tools/check_rom.py", args.rom.resolve())
        if not (SOURCE / "RecompiledFuncs/recomp_overlays.inl").is_file() or not (SOURCE / "src/aspMain.cpp").is_file():
            parser.error("Translation outputs missing; omit --reuse-translation")
        port_patch(SOURCE, ROOT / "patches/wdc-android.patch")
    else:
        run(*runtime_args)
    rt64 = SOURCE / "lib/rt64"
    if args.init:
        run("git", "submodule", "update", "--init", "--recursive", "--depth", "1", "--jobs", "8", *["src/contrib/" + name for name in GPU_DEPENDENCIES], cwd=rt64)
    patches("lib/rt64", ["0014-rt64-rdp-screen-clipping.patch", "0015-rt64-raw-triangle-scissor.patch", "0016-rt64-rdp-edge-trapezoids.patch"])
    port_patch(rt64, ROOT / "patches/rt64-android.patch")
    port_patch(rt64 / "src/contrib/plume", ROOT / "patches/plume-android.patch")
    converter = ROOT / "build/file-to-c"
    run("cmake", "-S", rt64 / "src/tools/file_to_c", "-B", converter, "-G", "Ninja", "-DCMAKE_BUILD_TYPE=Release")
    run("cmake", "--build", converter)
    sdk = toolchains / "android"
    build = ROOT / "build/android-player"
    run("cmake", "-S", SOURCE, "-B", build, "-G", "Ninja",
        f"-DCMAKE_TOOLCHAIN_FILE={sdk / 'ndk/28.2.13676358/build/cmake/android.toolchain.cmake'}",
        "-DANDROID_ABI=arm64-v8a", "-DANDROID_PLATFORM=android-29", "-DANDROID_STL=c++_static",
        "-DCMAKE_BUILD_TYPE=Release", "-DWDC_HEADLESS=OFF", "-DWDC_ENABLE_FRONTEND=OFF", "-DBUILD_TESTING=OFF",
        f"-DWDC_SDL_SOURCE_DIR={toolchains / 'SDL'}", f"-DWDC_HOST_FILE_TO_C={converter / 'file_to_c'}")
    run("cmake", "--build", build, "--target", "worlddriverchampionship_modern", "--parallel", args.jobs)
    run(sys.executable, ROOT / "tools/package_android.py", "--sdk", sdk, "--sdl", toolchains / "SDL", "--keystore", toolchains / "quest-debug.jks")


if __name__ == "__main__":
    try:
        main()
    except subprocess.CalledProcessError as exc:
        raise SystemExit(exc.returncode)
